<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');


    class Wp_users extends CI_Controller
{
    public $nama_template="template_admin";

    function __construct()
    {
        parent::__construct();
        $this->load->model('Wp_users_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->template->load($this->nama_template,'wp_users/wp_users_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Wp_users_model->json();
    }

    public function read($id) 
    {
        $row = $this->Wp_users_model->get_by_id($id);
        if ($row) {
            $data = array(
		'ID' => $row->ID,
		'user_login' => $row->user_login,
		'user_pass' => $row->user_pass,
		'user_nicename' => $row->user_nicename,
		'user_email' => $row->user_email,
		'user_url' => $row->user_url,
		'user_registered' => $row->user_registered,
		'user_activation_key' => $row->user_activation_key,
		'user_status' => $row->user_status,
		'display_name' => $row->display_name,
	    );
            $this->template->load($this->nama_template,'wp_users/wp_users_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('wp_users'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('wp_users/create_action'),
	    'ID' => set_value('ID'),
	    'user_login' => set_value('user_login'),
	    'user_pass' => set_value('user_pass'),
	    'user_nicename' => set_value('user_nicename'),
	    'user_email' => set_value('user_email'),
	    'user_url' => set_value('user_url'),
	    'user_registered' => set_value('user_registered'),
	    'user_activation_key' => set_value('user_activation_key'),
	    'user_status' => set_value('user_status'),
	    'display_name' => set_value('display_name'),
	);
        $this->template->load($this->nama_template,'wp_users/wp_users_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'user_login' => $this->input->post('user_login',TRUE),
		'user_pass' => $this->input->post('user_pass',TRUE),
		'user_nicename' => $this->input->post('user_nicename',TRUE),
		'user_email' => $this->input->post('user_email',TRUE),
		'user_url' => $this->input->post('user_url',TRUE),
		'user_registered' => $this->input->post('user_registered',TRUE),
		'user_activation_key' => $this->input->post('user_activation_key',TRUE),
		'user_status' => $this->input->post('user_status',TRUE),
		'display_name' => $this->input->post('display_name',TRUE),
	    );

            $this->Wp_users_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('wp_users'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Wp_users_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('wp_users/update_action'),
		'ID' => set_value('ID', $row->ID),
		'user_login' => set_value('user_login', $row->user_login),
		'user_pass' => set_value('user_pass', $row->user_pass),
		'user_nicename' => set_value('user_nicename', $row->user_nicename),
		'user_email' => set_value('user_email', $row->user_email),
		'user_url' => set_value('user_url', $row->user_url),
		'user_registered' => set_value('user_registered', $row->user_registered),
		'user_activation_key' => set_value('user_activation_key', $row->user_activation_key),
		'user_status' => set_value('user_status', $row->user_status),
		'display_name' => set_value('display_name', $row->display_name),
	    );
            $this->template->load($this->nama_template,'wp_users/wp_users_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('wp_users'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('ID', TRUE));
        } else {
            $data = array(
		'user_login' => $this->input->post('user_login',TRUE),
		'user_pass' => $this->input->post('user_pass',TRUE),
		'user_nicename' => $this->input->post('user_nicename',TRUE),
		'user_email' => $this->input->post('user_email',TRUE),
		'user_url' => $this->input->post('user_url',TRUE),
		'user_registered' => $this->input->post('user_registered',TRUE),
		'user_activation_key' => $this->input->post('user_activation_key',TRUE),
		'user_status' => $this->input->post('user_status',TRUE),
		'display_name' => $this->input->post('display_name',TRUE),
	    );

            $this->Wp_users_model->update($this->input->post('ID', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('wp_users'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Wp_users_model->get_by_id($id);

        if ($row) {
            $this->Wp_users_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('wp_users'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('wp_users'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('user_login', 'user login', 'trim|required');
	$this->form_validation->set_rules('user_pass', 'user pass', 'trim|required');
	$this->form_validation->set_rules('user_nicename', 'user nicename', 'trim|required');
	$this->form_validation->set_rules('user_email', 'user email', 'trim|required');
	$this->form_validation->set_rules('user_url', 'user url', 'trim|required');
	$this->form_validation->set_rules('user_registered', 'user registered', 'trim|required');
	$this->form_validation->set_rules('user_activation_key', 'user activation key', 'trim|required');
	$this->form_validation->set_rules('user_status', 'user status', 'trim|required');
	$this->form_validation->set_rules('display_name', 'display name', 'trim|required');

	$this->form_validation->set_rules('ID', 'ID', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Wp_users.php */
/* Location: ./application/controllers/Wp_users.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2019-07-08 10:35:32 */
/* http://harviacode.com */