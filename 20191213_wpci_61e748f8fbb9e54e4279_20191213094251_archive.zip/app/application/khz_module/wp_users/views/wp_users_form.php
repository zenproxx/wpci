
<div class="col-md-6 offset-md-3 col-sm-8 offset-sm-2 col-12">
<div class="card mt-5 mb-5">
    <div class="card-body">
       
       <div class="mt-2 mb-2">
           <h3 class="text-center">Wp_users</h3>
       </div>
       
    
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">User Login <?php echo form_error('user_login') ?></label>
            <input type="text" class="form-control" name="user_login" id="user_login" placeholder="User Login" value="<?php echo $user_login; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">User Pass <?php echo form_error('user_pass') ?></label>
            <input type="text" class="form-control" name="user_pass" id="user_pass" placeholder="User Pass" value="<?php echo $user_pass; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">User Nicename <?php echo form_error('user_nicename') ?></label>
            <input type="text" class="form-control" name="user_nicename" id="user_nicename" placeholder="User Nicename" value="<?php echo $user_nicename; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">User Email <?php echo form_error('user_email') ?></label>
            <input type="text" class="form-control" name="user_email" id="user_email" placeholder="User Email" value="<?php echo $user_email; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">User Url <?php echo form_error('user_url') ?></label>
            <input type="text" class="form-control" name="user_url" id="user_url" placeholder="User Url" value="<?php echo $user_url; ?>" />
        </div>
	    <div class="form-group">
            <label for="datetime">User Registered <?php echo form_error('user_registered') ?></label>
            <input type="text" class="form-control" name="user_registered" id="user_registered" placeholder="User Registered" value="<?php echo $user_registered; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">User Activation Key <?php echo form_error('user_activation_key') ?></label>
            <input type="text" class="form-control" name="user_activation_key" id="user_activation_key" placeholder="User Activation Key" value="<?php echo $user_activation_key; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">User Status <?php echo form_error('user_status') ?></label>
            <input type="text" class="form-control" name="user_status" id="user_status" placeholder="User Status" value="<?php echo $user_status; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Display Name <?php echo form_error('display_name') ?></label>
            <input type="text" class="form-control" name="display_name" id="display_name" placeholder="Display Name" value="<?php echo $display_name; ?>" />
        </div>
	    <input type="hidden" name="ID" value="<?php echo $ID; ?>" /> 
	    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> <?php echo $button ?></button> 
	    <a href="<?php echo base_url('wp_users') ?>" class="btn btn-warning"><i class="fa fa-angle-left"></i> Cancel</a>
	</form>
    </div>
</div>
</div>