<!doctype html>
<html>
<div class="col-md-12">
<div class="mt-4">
    <a style="padding: 9px 15px; background: #81c784; color: #fff; cursor: pointer; border-radius:3px;" onclick="goBack()"><i class="fa fa-angle-left"></i> Kembali</a>

    <script>
        function goBack() {
            window.history.back();
        }

    </script>
</div>

<div class="card" style="margin-top: 30px;">
    <div class="card-header">
        <h3>Wp_users List</h3>
    </div>

    <div class="card-body">
        <div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
            </div>
            <div class="col-md-4 text-center">
                <div style="margin-top: 4px" id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div>
            <div class="col-md-4 text-right">
                <?php echo anchor(base_url('wp_users/create'), '<i class="fa fa-plus"></i> Create', 'class="btn btn-primary"'); ?>
            </div>
        </div>

        <table style="width:100%;" class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
                    <th>No</th>
		    <th>User Login</th>
		    <th>User Pass</th>
		    <th>User Nicename</th>
		    <th>User Email</th>
		    <th>User Url</th>
		    <th>User Registered</th>
		    <th>User Activation Key</th>
		    <th>User Status</th>
		    <th>Display Name</th>
		  <th>Action</th>
                </tr>
            </thead>
        </table>
    </div>
</div>
</div>   
        <script>
            $(document).ready(function() {
                $.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings)
                {
                    return {
                        "iStart": oSettings._iDisplayStart,
                        "iEnd": oSettings.fnDisplayEnd(),
                        "iLength": oSettings._iDisplayLength,
                        "iTotal": oSettings.fnRecordsTotal(),
                        "iFilteredTotal": oSettings.fnRecordsDisplay(),
                        "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
                        "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
                    };
                };

                var t = $("#mytable").dataTable({
                    initComplete: function() {
                        var api = this.api();
                        $('#mytable_filter input')
                                .off('.DT')
                                .on('keyup.DT', function(e) {
                                    if (e.keyCode == 13) {
                                        api.search(this.value).draw();
                            }
                        });
                    },
                    oLanguage: {
                        sProcessing: "loading..."
                    },
                    processing: true,
                    serverSide: true,
                    ajax: {"url": "wp_users/json", "type": "POST"},
                    columns: [
                        {
                            "data": "ID",
                            "orderable": false
                        },{"data": "user_login"},{"data": "user_pass"},{"data": "user_nicename"},{"data": "user_email"},{"data": "user_url"},{"data": "user_registered"},{"data": "user_activation_key"},{"data": "user_status"},{"data": "display_name"},
                        {
                            "data" : "action",
                            "orderable": false,
                            "className" : "text-center"
                        }
                    ],
                    order: [[0, 'desc']],
                    rowCallback: function(row, data, iDisplayIndex) {
                        var info = this.fnPagingInfo();
                        var page = info.iPage;
                        var length = info.iLength;
                        var index = page * length + (iDisplayIndex + 1);
                        $('td:eq(0)', row).html(index);
                    }
                });
            });
        </script>
