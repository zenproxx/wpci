
<div class="col-md-6 offset-md-3 col-sm-8 offset-sm-2 col-12">
    <div class="card mt-5 mb-5">
        <div class="card-body">
           
           <div class="mt-2 mb-2">
               <h3 class="text-center">Wp_users Read</h3>
           </div>
           
            <table border="0" class="table">
	    <tr><td>User Login</td><td><?php echo $user_login; ?></td></tr>
	    <tr><td>User Pass</td><td><?php echo $user_pass; ?></td></tr>
	    <tr><td>User Nicename</td><td><?php echo $user_nicename; ?></td></tr>
	    <tr><td>User Email</td><td><?php echo $user_email; ?></td></tr>
	    <tr><td>User Url</td><td><?php echo $user_url; ?></td></tr>
	    <tr><td>User Registered</td><td><?php echo $user_registered; ?></td></tr>
	    <tr><td>User Activation Key</td><td><?php echo $user_activation_key; ?></td></tr>
	    <tr><td>User Status</td><td><?php echo $user_status; ?></td></tr>
	    <tr><td>Display Name</td><td><?php echo $display_name; ?></td></tr>  </table>
            
            <div class="text-center">
                <a href="<?php echo base_url('wp_users') ?>" class="btn btn-primary"><i class="fa fa-angle-left"></i> Kembali</a>
            </div>
            
        </div>
    </div>
</div>