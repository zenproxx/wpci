<div style="width: 100px; margin: 10px auto; background: #aaa;">
    <p style="text-align: center;">Ini adalah Konten</p>
</div>