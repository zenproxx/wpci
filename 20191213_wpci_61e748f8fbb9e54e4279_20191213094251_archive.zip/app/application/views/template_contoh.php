<html>

<head>
	<title>wew</title>
</head>

<body>

<p style="text-align: center;">Konten ada di bawah ini</p>

<?php echo $contents; ?>

</body>

</html>